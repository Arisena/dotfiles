/home/ari/Music/10 Years/Feeding The Wolves/01 Shoot It Out.mp3
/home/ari/Music/10 Years/Feeding The Wolves/02 The Wicked Ones.mp3
/home/ari/Music/10 Years/Feeding The Wolves/03 Now Is The Time (Ravenous).mp3
/home/ari/Music/10 Years/Feeding The Wolves/04 One More Day.mp3
/home/ari/Music/10 Years/Feeding The Wolves/05 Fix Me.mp3
/home/ari/Music/10 Years/Feeding The Wolves/06 Chasing The Rapture.mp3
/home/ari/Music/10 Years/Feeding The Wolves/07 Dead In The Water.mp3
/home/ari/Music/10 Years/Feeding The Wolves/08 Don't Fight It.mp3
/home/ari/Music/10 Years/Feeding The Wolves/09 Waking Up The Ghost.mp3
/home/ari/Music/10 Years/Feeding The Wolves/10 Fade Into (The Ocean).mp3
/home/ari/Music/All That Remains/The Order of Things/01 This Probably Won't End Well.mp3
/home/ari/Music/All That Remains/The Order of Things/02 No Knock.mp3
/home/ari/Music/All That Remains/The Order of Things/03 Divide.mp3
/home/ari/Music/All That Remains/The Order of Things/04 The Greatest Generation.mp3
/home/ari/Music/All That Remains/The Order of Things/05 For You.mp3
/home/ari/Music/All That Remains/The Order of Things/06 A Reason for Me to Fight.mp3
/home/ari/Music/All That Remains/The Order of Things/07 Victory Lap.mp3
/home/ari/Music/All That Remains/The Order of Things/08 Pernicious.mp3
/home/ari/Music/All That Remains/The Order of Things/09 Bite My Tongue.mp3
/home/ari/Music/All That Remains/The Order of Things/10 Fiat Empire.mp3
/home/ari/Music/All That Remains/The Order of Things/11 Tru-Kvlt-Metal.mp3
/home/ari/Music/All That Remains/The Order of Things/12 Criticism and Self Realization.mp3
/home/ari/Music/Avenged Sevenfold/City Of Evil (PA Version)/01 Beast and the Harlot.mp3
/home/ari/Music/Avenged Sevenfold/City Of Evil (PA Version)/02 Burn It Down.mp3
/home/ari/Music/Avenged Sevenfold/City Of Evil (PA Version)/03 Blinded In Chains.mp3
/home/ari/Music/Avenged Sevenfold/City Of Evil (PA Version)/04 Bat Country.mp3
/home/ari/Music/Avenged Sevenfold/City Of Evil (PA Version)/05 Trashed And Scattered.mp3
/home/ari/Music/Avenged Sevenfold/City Of Evil (PA Version)/06 Seize the Day.mp3
/home/ari/Music/Avenged Sevenfold/City Of Evil (PA Version)/07 Sidewinder.mp3
/home/ari/Music/Avenged Sevenfold/City Of Evil (PA Version)/08 The Wicked End.mp3
/home/ari/Music/Avenged Sevenfold/City Of Evil (PA Version)/09 Strength Of The World.mp3
/home/ari/Music/Avenged Sevenfold/City Of Evil (PA Version)/10 Betrayed.mp3
/home/ari/Music/Avenged Sevenfold/City Of Evil (PA Version)/11 M_I_A_.mp3
/home/ari/Music/Black Tide/Post Mortem/01 Ashes (feat_ Matt Tuck).mp3
/home/ari/Music/Black Tide/Post Mortem/02 Bury Me.mp3
/home/ari/Music/Black Tide/Post Mortem/03 Let It Out.mp3
/home/ari/Music/Black Tide/Post Mortem/04 Honest Eyes.mp3
/home/ari/Music/Black Tide/Post Mortem/05 That Fire.mp3
/home/ari/Music/Black Tide/Post Mortem/06 Fight Til The Bitter End.mp3
/home/ari/Music/Black Tide/Post Mortem/07 Take It Easy.mp3
/home/ari/Music/Black Tide/Post Mortem/08 Lost In The Sound.mp3
/home/ari/Music/Black Tide/Post Mortem/09 Walking Dead Man.mp3
/home/ari/Music/Black Tide/Post Mortem/10 Into The Sky.mp3
/home/ari/Music/Children Of Bodom/Halo of Blood (Bonus Track Ver/01 Waste of Skin.mp3
/home/ari/Music/Children Of Bodom/Halo of Blood (Bonus Track Ver/02 Halo of Blood.mp3
/home/ari/Music/Children Of Bodom/Halo of Blood (Bonus Track Ver/03 Scream for Silence.mp3
/home/ari/Music/Children Of Bodom/Halo of Blood (Bonus Track Ver/04 Transference.mp3
/home/ari/Music/Children Of Bodom/Halo of Blood (Bonus Track Ver/05 Bodom Blue Moon (The Second Co.mp3
/home/ari/Music/Children Of Bodom/Halo of Blood (Bonus Track Ver/06 Your Days Are Numbered.mp3
/home/ari/Music/Children Of Bodom/Halo of Blood (Bonus Track Ver/07 Dead Man's Hand on You.mp3
/home/ari/Music/Children Of Bodom/Halo of Blood (Bonus Track Ver/08 Damaged Beyond Repair.mp3
/home/ari/Music/Children Of Bodom/Halo of Blood (Bonus Track Ver/09 All Twisted.mp3
/home/ari/Music/Children Of Bodom/Halo of Blood (Bonus Track Ver/10 One Bottle and a Knee Deep.mp3
/home/ari/Music/Children Of Bodom/Halo of Blood (Bonus Track Ver/11 Sleeping in My Car (Bonus Trac.mp3
/home/ari/Music/Children Of Bodom/I Worship Chaos/01 I Hurt.mp3
/home/ari/Music/Children Of Bodom/I Worship Chaos/02 My Bodom (I Am the Only One).mp3
/home/ari/Music/Children Of Bodom/I Worship Chaos/03 Morrigan.mp3
/home/ari/Music/Children Of Bodom/I Worship Chaos/04 Horns.mp3
/home/ari/Music/Children Of Bodom/I Worship Chaos/05 Prayer for the Afflicted.mp3
/home/ari/Music/Children Of Bodom/I Worship Chaos/06 I Worship Chaos.mp3
/home/ari/Music/Children Of Bodom/I Worship Chaos/07 Hold Your Tongue.mp3
/home/ari/Music/Children Of Bodom/I Worship Chaos/08 Suicide Bomber.mp3
/home/ari/Music/Children Of Bodom/I Worship Chaos/09 All for Nothing.mp3
/home/ari/Music/Children Of Bodom/I Worship Chaos/10 Widdershins.mp3
/home/ari/Music/Children Of Bodom/I Worship Chaos/11 Mistress of Taboo (Bonus Track.mp3
/home/ari/Music/Children Of Bodom/I Worship Chaos/12 Danger Zone (Bonus Track).mp3
/home/ari/Music/Children Of Bodom/I Worship Chaos/13 Black Winter Day (Bonus Track).mp3
/home/ari/Music/Cold/Year Of The Spider/01 Remedy.mp3
/home/ari/Music/Cold/Year Of The Spider/02 Suffocate (Explicit).mp3
/home/ari/Music/Cold/Year Of The Spider/03 Cure My Tragedy (Explicit).mp3
/home/ari/Music/Cold/Year Of The Spider/04 Stupid Girl.mp3
/home/ari/Music/Cold/Year Of The Spider/05 Don't Belong.mp3
/home/ari/Music/Cold/Year Of The Spider/06 Wasted Years.mp3
/home/ari/Music/Cold/Year Of The Spider/07 Whatever You Became.mp3
/home/ari/Music/Cold/Year Of The Spider/08 Sad Happy.mp3
/home/ari/Music/Cold/Year Of The Spider/09 Rain Song.mp3
/home/ari/Music/Cold/Year Of The Spider/10 The Day Seattle Died.mp3
/home/ari/Music/Cold/Year Of The Spider/11 Change The World.mp3
/home/ari/Music/Cold/Year Of The Spider/12 Black Sunday.mp3
/home/ari/Music/Cold/Year Of The Spider/13 Kill The Music Industry (Expli.mp3
/home/ari/Music/Cold/Year Of The Spider/14 Gone Away (A Song For Starr).mp3
/home/ari/Music/Cold/Superfiction/01 Wicked World.mp3
/home/ari/Music/Cold/Superfiction/02 What Happens Now.mp3
/home/ari/Music/Cold/Superfiction/03 American Dream.mp3
/home/ari/Music/Cold/Superfiction/04 The Break.mp3
/home/ari/Music/Cold/Superfiction/05 Welcome2MyWorld.mp3
/home/ari/Music/Cold/Superfiction/06 Emily.mp3
/home/ari/Music/Cold/Superfiction/07 The Crossroads.mp3
/home/ari/Music/Cold/Superfiction/08 Delivering the Saint.mp3
/home/ari/Music/Cold/Superfiction/09 So Long June.mp3
/home/ari/Music/Cold/Superfiction/10 The Park.mp3
/home/ari/Music/Cold/Superfiction/11 Flight of the Superstar.mp3
/home/ari/Music/Cold/Superfiction/12 The Ballad of the Nameless.mp3
/home/ari/Music/Demon Hunter/The Triptych/01 The Flame That Guides Us Home.mp3
/home/ari/Music/Demon Hunter/The Triptych/02 Not I.mp3
/home/ari/Music/Demon Hunter/The Triptych/03 Undying.mp3
/home/ari/Music/Demon Hunter/The Triptych/04 Relentless Intolerance.mp3
/home/ari/Music/Demon Hunter/The Triptych/05 Deteriorate.mp3
/home/ari/Music/Demon Hunter/The Triptych/06 The Soldier's Song.mp3
/home/ari/Music/Demon Hunter/The Triptych/07 Fire to My Soul.mp3
/home/ari/Music/Demon Hunter/The Triptych/08 One Thousand Apologies.mp3
/home/ari/Music/Demon Hunter/The Triptych/09 The Science of Lies.mp3
/home/ari/Music/Demon Hunter/The Triptych/10 Snap Your Fingers_ Snap Your N.mp3
/home/ari/Music/Demon Hunter/The Triptych/11 Ribcage.mp3
/home/ari/Music/Demon Hunter/The Triptych/12 The Tide Began to Rise.mp3
/home/ari/Music/Devour The Day/Time & Pressure/01 Respect(1).mp3
/home/ari/Music/Devour The Day/Time & Pressure/01 Respect.mp3
/home/ari/Music/Devour The Day/Time & Pressure/02 Good Man.mp3
/home/ari/Music/Devour The Day/Time & Pressure/03 Blackout.mp3
/home/ari/Music/Devour The Day/Time & Pressure/04 You And Not Me.mp3
/home/ari/Music/Devour The Day/Time & Pressure/05 Move On.mp3
/home/ari/Music/Devour The Day/Time & Pressure/06 Get Out Of My Way.mp3
/home/ari/Music/Devour The Day/Time & Pressure/07 Oath.mp3
/home/ari/Music/Devour The Day/Time & Pressure/08 Reckless.mp3
/home/ari/Music/Devour The Day/Time & Pressure/09 Handshakes To Fist Fights.mp3
/home/ari/Music/Devour The Day/Time & Pressure/10 Crossroads.mp3
/home/ari/Music/Devour The Day/Time & Pressure/11 The Drifter.mp3
/home/ari/Music/Devour The Day/Time & Pressure/12 Check Your Head.mp3
/home/ari/Music/Devour The Day/Time & Pressure/13 Good Man (Acoustic).mp3
/home/ari/Music/Disturbed/Immortalized (Deluxe Version)/01 The Eye Of The Storm.mp3
/home/ari/Music/Disturbed/Immortalized (Deluxe Version)/02 Immortalized.mp3
/home/ari/Music/Disturbed/Immortalized (Deluxe Version)/03 The Vengeful One.mp3
/home/ari/Music/Disturbed/Immortalized (Deluxe Version)/04 Open Your Eyes.mp3
/home/ari/Music/Disturbed/Immortalized (Deluxe Version)/05 The Light.mp3
/home/ari/Music/Disturbed/Immortalized (Deluxe Version)/06 What Are You Waiting For.mp3
/home/ari/Music/Disturbed/Immortalized (Deluxe Version)/07 You're Mine.mp3
/home/ari/Music/Disturbed/Immortalized (Deluxe Version)/08 Who.mp3
/home/ari/Music/Disturbed/Immortalized (Deluxe Version)/09 Save Our Last Goodbye.mp3
/home/ari/Music/Disturbed/Immortalized (Deluxe Version)/10 Fire It Up.mp3
/home/ari/Music/Disturbed/Immortalized (Deluxe Version)/11 The Sound Of Silence.mp3
/home/ari/Music/Disturbed/Immortalized (Deluxe Version)/12 Never Wrong.mp3
/home/ari/Music/Disturbed/Immortalized (Deluxe Version)/13 Who Taught You How To Hate.mp3
/home/ari/Music/Disturbed/Immortalized (Deluxe Version)/14 Tyrant (Bonus Track).mp3
/home/ari/Music/Disturbed/Immortalized (Deluxe Version)/15 Legion Of Monsters (Bonus Trac.mp3
/home/ari/Music/Disturbed/Immortalized (Deluxe Version)/16 The Brave And The Bold (Bonus.mp3
/home/ari/Music/Disturbed/Ten Thousand Fists/01 Ten Thousand Fists.mp3
/home/ari/Music/Disturbed/Ten Thousand Fists/02 Just Stop.mp3
/home/ari/Music/Disturbed/Ten Thousand Fists/03 Guarded.mp3
/home/ari/Music/Disturbed/Ten Thousand Fists/04 Deify.mp3
/home/ari/Music/Disturbed/Ten Thousand Fists/05 Stricken.mp3
/home/ari/Music/Disturbed/Ten Thousand Fists/06 I'm Alive.mp3
/home/ari/Music/Disturbed/Ten Thousand Fists/07 Sons of Plunder.mp3
/home/ari/Music/Disturbed/Ten Thousand Fists/08 Overburdened.mp3
/home/ari/Music/Disturbed/Ten Thousand Fists/09 Decadence.mp3
/home/ari/Music/Disturbed/Ten Thousand Fists/10 Forgiven.mp3
/home/ari/Music/Disturbed/Ten Thousand Fists/11 Land of Confusion.mp3
/home/ari/Music/Disturbed/Ten Thousand Fists/12 Sacred Lie.mp3
/home/ari/Music/Disturbed/Ten Thousand Fists/13 Pain Redefined.mp3
/home/ari/Music/Disturbed/Ten Thousand Fists/14 Avarice.mp3
/home/ari/Music/Elvenking/The Pagan Manifesto/01 The Manifesto.mp3
/home/ari/Music/Elvenking/The Pagan Manifesto/02 King of the Elves.mp3
/home/ari/Music/Elvenking/The Pagan Manifesto/03 Elvenlegions.mp3
/home/ari/Music/Elvenking/The Pagan Manifesto/04 The Druid Ritual of Oak.mp3
/home/ari/Music/Elvenking/The Pagan Manifesto/05 Moonbeam Stone Circle.mp3
/home/ari/Music/Elvenking/The Pagan Manifesto/06 The Solitaire.mp3
/home/ari/Music/Elvenking/The Pagan Manifesto/07 Towards the Shores.mp3
/home/ari/Music/Elvenking/The Pagan Manifesto/08 Pagan Revolution.mp3
/home/ari/Music/Elvenking/The Pagan Manifesto/09 Grandier's Funeral Pyre.mp3
/home/ari/Music/Elvenking/The Pagan Manifesto/10 Twilight of Magic.mp3
/home/ari/Music/Elvenking/The Pagan Manifesto/11 Black Roses for the Wicked One.mp3
/home/ari/Music/Elvenking/The Pagan Manifesto/12 Witches Gather.mp3
/home/ari/Music/Elvenking/The Scythe/01 The Scythe.mp3
/home/ari/Music/Elvenking/The Scythe/02 Lost Hill of Memories.mp3
/home/ari/Music/Elvenking/The Scythe/03 Infection.mp3
/home/ari/Music/Elvenking/The Scythe/04 Poison Tears.mp3
/home/ari/Music/Elvenking/The Scythe/05 A Riddle of Stars.mp3
/home/ari/Music/Elvenking/The Scythe/06 Romance & Wrath.mp3
/home/ari/Music/Elvenking/The Scythe/07 The Divided Heart.mp3
/home/ari/Music/Elvenking/The Scythe/08 Totentanz.mp3
/home/ari/Music/Elvenking/The Scythe/09 Death and the Suffering.mp3
/home/ari/Music/Elvenking/The Scythe/10 Dominhate.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/01 Lift Me Up.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/02 Watch You Bleed.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/03 You.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/04 Wrong Side of Heaven.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/05 Burn MF.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/06 I_M_Sin.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/07 Anywhere But Here (feat_ Maria.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/08 Dot Your Eyes.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/09 M_I_N_E (End This Way).mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/10 Mama Said Knock You Out (feat_.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/11 Diary of a Deadman.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/12 I_M_Sin.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/13 Anywhere But Here.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/14 Dot Your Eyes.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/1-02 Watch You Bleed.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/01 Here To Die.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/02 Weight Beneath My Sin.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/03 Wrecking Ball.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/04 Battle Born.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/05 Cradle To The Grave.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/06 Matter Of Time.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/07 The Agony Of Regret.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/08 Cold.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/09 Let This Go.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/10 My Heart Lied.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/11 A Day In My Life.mp3
/home/ari/Music/Five Finger Death Punch/The Wrong Side Of Heaven And T/12 House Of The Rising Sun.mp3
/home/ari/Music/Five Finger Death Punch/Got Your Six (Deluxe)/01 Got Your Six.mp3
/home/ari/Music/Five Finger Death Punch/Got Your Six (Deluxe)/02 Jekyll And Hyde.mp3
/home/ari/Music/Five Finger Death Punch/Got Your Six (Deluxe)/03 Wash It All Away.mp3
/home/ari/Music/Five Finger Death Punch/Got Your Six (Deluxe)/04 Ain't My Last Dance.mp3
/home/ari/Music/Five Finger Death Punch/Got Your Six (Deluxe)/05 My Nemesis.mp3
/home/ari/Music/Five Finger Death Punch/Got Your Six (Deluxe)/06 No Sudden Movement.mp3
/home/ari/Music/Five Finger Death Punch/Got Your Six (Deluxe)/07 Question Everything.mp3
/home/ari/Music/Five Finger Death Punch/Got Your Six (Deluxe)/08 Hell To Pay.mp3
/home/ari/Music/Five Finger Death Punch/Got Your Six (Deluxe)/09 Digging My Own Grave.mp3
/home/ari/Music/Five Finger Death Punch/Got Your Six (Deluxe)/10 Meet My Maker.mp3
/home/ari/Music/Five Finger Death Punch/Got Your Six (Deluxe)/11 Boots And Blood.mp3
/home/ari/Music/Five Finger Death Punch/Got Your Six (Deluxe)/12 You're Not My Kind.mp3
/home/ari/Music/Five Finger Death Punch/Got Your Six (Deluxe)/13 This Is My War.mp3
/home/ari/Music/Five Finger Death Punch/Got Your Six (Deluxe)/14 I Apologize.mp3
/home/ari/Music/Gloryhammer/Space 1992_ Rise of the Chaos/01 Infernus Ad Astra.mp3
/home/ari/Music/Gloryhammer/Space 1992_ Rise of the Chaos/02 Rise Of The Chaos Wizards.mp3
/home/ari/Music/Gloryhammer/Space 1992_ Rise of the Chaos/03 Legend Of The Astral Hammer.mp3
/home/ari/Music/Gloryhammer/Space 1992_ Rise of the Chaos/04 Goblin King Of The Darkstorm G.mp3
/home/ari/Music/Gloryhammer/Space 1992_ Rise of the Chaos/05 The Hollywood Hootsman.mp3
/home/ari/Music/Gloryhammer/Space 1992_ Rise of the Chaos/06 Victorious Eagle Warfare.mp3
/home/ari/Music/Gloryhammer/Space 1992_ Rise of the Chaos/07 Questlords Of Inverness_ Ride.mp3
/home/ari/Music/Gloryhammer/Space 1992_ Rise of the Chaos/08 Universe On Fire.mp3
/home/ari/Music/Gloryhammer/Space 1992_ Rise of the Chaos/09 Heroes (Of Dundee).mp3
/home/ari/Music/Gloryhammer/Space 1992_ Rise of the Chaos/10 Apocalypse 1992.mp3
/home/ari/Music/Gloryhammer/Space 1992_ Rise of the Chaos/11 Main Title.mp3
/home/ari/Music/Gloryhammer/Space 1992_ Rise of the Chaos/12 The Attack On Triton.mp3
/home/ari/Music/Gloryhammer/Space 1992_ Rise of the Chaos/13 Angus McFife XIII's Theme.mp3
/home/ari/Music/Gloryhammer/Space 1992_ Rise of the Chaos/14 An Evil Wizard Does A Quest.mp3
/home/ari/Music/Gloryhammer/Space 1992_ Rise of the Chaos/15 The King Of California.mp3
/home/ari/Music/Gloryhammer/Space 1992_ Rise of the Chaos/16 Ser Proletius Returns.mp3
/home/ari/Music/Gloryhammer/Space 1992_ Rise of the Chaos/17 Lords Of Space And Time.mp3
/home/ari/Music/Gloryhammer/Space 1992_ Rise of the Chaos/18 To Claim Space Throne.mp3
/home/ari/Music/Gloryhammer/Space 1992_ Rise of the Chaos/19 An Epic War Is Fight.mp3
/home/ari/Music/Gloryhammer/Space 1992_ Rise of the Chaos/20 Dundee Will Fall.mp3
/home/ari/Music/Gloryhammer/Tales From The Kingdom Of Fife/01 Anstruther's Dark Prophecy.mp3
/home/ari/Music/Gloryhammer/Tales From The Kingdom Of Fife/02 The Unicorn Invasion of Dundee.mp3
/home/ari/Music/Gloryhammer/Tales From The Kingdom Of Fife/03 Angus McFife.mp3
/home/ari/Music/Gloryhammer/Tales From The Kingdom Of Fife/04 Quest for the Hammer of Glory.mp3
/home/ari/Music/Gloryhammer/Tales From The Kingdom Of Fife/05 Magic Dragon.mp3
/home/ari/Music/Gloryhammer/Tales From The Kingdom Of Fife/06 Silent Tears of Frozen Princes.mp3
/home/ari/Music/Gloryhammer/Tales From The Kingdom Of Fife/07 Amulet of Justice.mp3
/home/ari/Music/Gloryhammer/Tales From The Kingdom Of Fife/08 Hail to Crail.mp3
/home/ari/Music/Gloryhammer/Tales From The Kingdom Of Fife/09 Beneath Cowdenbeath.mp3
/home/ari/Music/Gloryhammer/Tales From The Kingdom Of Fife/10 The Epic Rage of Furious Thund.mp3
/home/ari/Music/Gloryhammer/Tales From The Kingdom Of Fife/11 Wizards! (Bonus Track).mp3
/home/ari/Music/Linkin Park/Minutes To Midnight/04 Bleed It Out.mp3
/home/ari/Music/Nine Lashes/World We View/01 Anthem of the Lonely.mp3
/home/ari/Music/Nine Lashes/World We View/02 The Intervention.mp3
/home/ari/Music/Nine Lashes/World We View/03 Get Back.mp3
/home/ari/Music/Nine Lashes/World We View/04 Afterglow.mp3
/home/ari/Music/Nine Lashes/World We View/05 Adrenaline.mp3
/home/ari/Music/Nine Lashes/World We View/06 Believe Your Eyes.mp3
/home/ari/Music/Nine Lashes/World We View/07 Our Darkest Day.mp3
/home/ari/Music/Nine Lashes/World We View/08 Memo.mp3
/home/ari/Music/Nine Lashes/World We View/09 Write It Down.mp3
/home/ari/Music/Nine Lashes/World We View/10 The Void.mp3
/home/ari/Music/Nine Lashes/World We View/11 My Friend.mp3
/home/ari/Music/Nine Lashes/From Water to War/01 Never Back Down.mp3
/home/ari/Music/Nine Lashes/From Water to War/02 Break the World.mp3
/home/ari/Music/Nine Lashes/From Water to War/03 Where I Belong.mp3
/home/ari/Music/Nine Lashes/From Water to War/04 Lights We Burn.mp3
/home/ari/Music/Nine Lashes/From Water to War/05 Surrender.mp3
/home/ari/Music/Nine Lashes/From Water to War/06 You Are the Light.mp3
/home/ari/Music/Nine Lashes/From Water to War/07 In the Dark.mp3
/home/ari/Music/Nine Lashes/From Water to War/08 Light It Up.mp3
/home/ari/Music/Nine Lashes/From Water to War/09 Love Me Now.mp3
/home/ari/Music/Nine Lashes/From Water to War/10 Cover Your Own.mp3
/home/ari/Music/Papa Roach/F_E_A_R_/01 Face Everything and Rise.mp3
/home/ari/Music/Papa Roach/F_E_A_R_/02 Skeletons.mp3
/home/ari/Music/Papa Roach/F_E_A_R_/03 Broken as Me.mp3
/home/ari/Music/Papa Roach/F_E_A_R_/04 Falling Apart.mp3
/home/ari/Music/Papa Roach/F_E_A_R_/05 Love Me Till It Hurts.mp3
/home/ari/Music/Papa Roach/F_E_A_R_/06 Never Have to Say Goodbye.mp3
/home/ari/Music/Papa Roach/F_E_A_R_/07 Gravity.mp3
/home/ari/Music/Papa Roach/F_E_A_R_/08 War over Me.mp3
/home/ari/Music/Papa Roach/F_E_A_R_/09 Devil.mp3
/home/ari/Music/Papa Roach/F_E_A_R_/10 Warriors.mp3
/home/ari/Music/Papa Roach/F_E_A_R_/11 Hope for the Hopeless.mp3
/home/ari/Music/Papa Roach/F_E_A_R_/12 Fear Hate Love.mp3
/home/ari/Music/Pillar/Where Do We Go From Here/04 Let It Out.mp3
/home/ari/Music/Powerwolf/Blood of the Saints/01 Agnus Dei (Intro).mp3
/home/ari/Music/Powerwolf/Blood of the Saints/02 Sanctified with Dynamite.mp3
/home/ari/Music/Powerwolf/Blood of the Saints/03 We Drink Your Blood.mp3
/home/ari/Music/Powerwolf/Blood of the Saints/04 Murder at Midnight.mp3
/home/ari/Music/Powerwolf/Blood of the Saints/05 All We Need is Blood.mp3
/home/ari/Music/Powerwolf/Blood of the Saints/06 Dead Boys Don't Cry.mp3
/home/ari/Music/Powerwolf/Blood of the Saints/07 Son of a Wolf.mp3
/home/ari/Music/Powerwolf/Blood of the Saints/08 Night of the Werewolves.mp3
/home/ari/Music/Powerwolf/Blood of the Saints/09 Phanoton of the Funeral.mp3
/home/ari/Music/Powerwolf/Blood of the Saints/10 Die_ Die_ Crucify.mp3
/home/ari/Music/Powerwolf/Blood of the Saints/11 Ira Sancti (When the Saints Ar.mp3
/home/ari/Music/Powerwolf/Blessed and Possessed/01 Blessed & Possessed.mp3
/home/ari/Music/Powerwolf/Blessed and Possessed/02 Dead Until Dark.mp3
/home/ari/Music/Powerwolf/Blessed and Possessed/03 Army Of The Night.mp3
/home/ari/Music/Powerwolf/Blessed and Possessed/04 Armata Strigoi.mp3
/home/ari/Music/Powerwolf/Blessed and Possessed/05 We Are The Wild.mp3
/home/ari/Music/Powerwolf/Blessed and Possessed/06 Higher Than Heaven.mp3
/home/ari/Music/Powerwolf/Blessed and Possessed/07 Christ & Combat.mp3
/home/ari/Music/Powerwolf/Blessed and Possessed/08 Sanctus Dominus.mp3
/home/ari/Music/Powerwolf/Blessed and Possessed/09 Sacramental Sister.mp3
/home/ari/Music/Powerwolf/Blessed and Possessed/10 All You Can Bleed.mp3
/home/ari/Music/Powerwolf/Blessed and Possessed/11 Let There Be Night.mp3
/home/ari/Music/Rhapsody Of Fire/Dark Wings of Steel/01 Vis Divina.mp3
/home/ari/Music/Rhapsody Of Fire/Dark Wings of Steel/02 Rising from Tragic Flames.mp3
/home/ari/Music/Rhapsody Of Fire/Dark Wings of Steel/03 Angel of Light.mp3
/home/ari/Music/Rhapsody Of Fire/Dark Wings of Steel/04 Tears of Pain.mp3
/home/ari/Music/Rhapsody Of Fire/Dark Wings of Steel/05 Fly to Crystal Skies.mp3
/home/ari/Music/Rhapsody Of Fire/Dark Wings of Steel/06 My Sacrifice.mp3
/home/ari/Music/Rhapsody Of Fire/Dark Wings of Steel/07 Silver Lake of Tears.mp3
/home/ari/Music/Rhapsody Of Fire/Dark Wings of Steel/08 Custode Di Pace.mp3
/home/ari/Music/Rhapsody Of Fire/Dark Wings of Steel/09 A Tale of Magic.mp3
/home/ari/Music/Rhapsody Of Fire/Dark Wings of Steel/10 Dark Wings of Steel.mp3
/home/ari/Music/Rhapsody Of Fire/Dark Wings of Steel/11 Sad Mystic Moon.mp3
/home/ari/Music/Rhapsody Of Fire/Into the Legend/01 In Principio.mp3
/home/ari/Music/Rhapsody Of Fire/Into the Legend/02 Distant Sky.mp3
/home/ari/Music/Rhapsody Of Fire/Into the Legend/03 Into the Legend.mp3
/home/ari/Music/Rhapsody Of Fire/Into the Legend/04 Winter's Rain.mp3
/home/ari/Music/Rhapsody Of Fire/Into the Legend/05 A Voice in the Cold Wind.mp3
/home/ari/Music/Rhapsody Of Fire/Into the Legend/06 Valley of Shadows.mp3
/home/ari/Music/Rhapsody Of Fire/Into the Legend/07 Shining Star.mp3
/home/ari/Music/Rhapsody Of Fire/Into the Legend/08 Realms of Light.mp3
/home/ari/Music/Rhapsody Of Fire/Into the Legend/09 Rage of Darkness.mp3
/home/ari/Music/Rhapsody Of Fire/Into the Legend/10 The Kiss of Life.mp3
/home/ari/Music/Sabaton/Heroes (Bonus Version)/01 Night Witches.mp3
/home/ari/Music/Sabaton/Heroes (Bonus Version)/02 No Bullets Fly.mp3
/home/ari/Music/Sabaton/Heroes (Bonus Version)/03 Smoking Snakes.mp3
/home/ari/Music/Sabaton/Heroes (Bonus Version)/04 Inmate 4859.mp3
/home/ari/Music/Sabaton/Heroes (Bonus Version)/05 To Hell and Back.mp3
/home/ari/Music/Sabaton/Heroes (Bonus Version)/06 The Ballad of Bull.mp3
/home/ari/Music/Sabaton/Heroes (Bonus Version)/07 Resist and Bite.mp3
/home/ari/Music/Sabaton/Heroes (Bonus Version)/08 Soldier of 3 Armies.mp3
/home/ari/Music/Sabaton/Heroes (Bonus Version)/09 Far from the Fame.mp3
/home/ari/Music/Sabaton/Heroes (Bonus Version)/10 Hearts of Iron.mp3
/home/ari/Music/Sabaton/Heroes (Bonus Version)/11 7734.mp3
/home/ari/Music/Sabaton/Heroes (Bonus Version)/12 Man of War.mp3
/home/ari/Music/Sabaton/Heroes (Bonus Version)/13 For Whom the Bell Tolls (Metal.mp3
/home/ari/Music/Sabaton/The Art Of War (Re-Armed)/01 Sun Tzu Says.mp3
/home/ari/Music/Sabaton/The Art Of War (Re-Armed)/02 Ghost Division.mp3
/home/ari/Music/Sabaton/The Art Of War (Re-Armed)/03 The Art Of War.mp3
/home/ari/Music/Sabaton/The Art Of War (Re-Armed)/04 40_1.mp3
/home/ari/Music/Sabaton/The Art Of War (Re-Armed)/05 Unbreakable.mp3
/home/ari/Music/Sabaton/The Art Of War (Re-Armed)/06 The Nature Of Warfare.mp3
/home/ari/Music/Sabaton/The Art Of War (Re-Armed)/07 Cliffs Of Gallipoli.mp3
/home/ari/Music/Sabaton/The Art Of War (Re-Armed)/08 Talvisota.mp3
/home/ari/Music/Sabaton/The Art Of War (Re-Armed)/09 Panzerkampf.mp3
/home/ari/Music/Sabaton/The Art Of War (Re-Armed)/10 Union (Slopes Of St_Benedict).mp3
/home/ari/Music/Sabaton/The Art Of War (Re-Armed)/11 The Price Of A Mile.mp3
/home/ari/Music/Sabaton/The Art Of War (Re-Armed)/12 Firestorm.mp3
/home/ari/Music/Sabaton/The Art Of War (Re-Armed)/13 A Secret.mp3
/home/ari/Music/Sabaton/The Art Of War (Re-Armed)/14 Swedish Pagans.mp3
/home/ari/Music/Sabaton/The Art Of War (Re-Armed)/15 Glorious Land.mp3
/home/ari/Music/Sabaton/The Art Of War (Re-Armed)/16 Art Of War (Pre Production Dem.mp3
/home/ari/Music/Sabaton/The Art Of War (Re-Armed)/17 Swedish National Anthem (Live.mp3
/home/ari/Music/Sabaton/Primo Victoria (Re-Armed)/01 Primo Victoria.mp3
/home/ari/Music/Sabaton/Primo Victoria (Re-Armed)/02 Reign Of Terror.mp3
/home/ari/Music/Sabaton/Primo Victoria (Re-Armed)/03 Panzer Battalion.mp3
/home/ari/Music/Sabaton/Primo Victoria (Re-Armed)/04 Wolfpack.mp3
/home/ari/Music/Sabaton/Primo Victoria (Re-Armed)/05 Counterstrike.mp3
/home/ari/Music/Sabaton/Primo Victoria (Re-Armed)/06 Stalingrad.mp3
/home/ari/Music/Sabaton/Primo Victoria (Re-Armed)/07 Into The Fire.mp3
/home/ari/Music/Sabaton/Primo Victoria (Re-Armed)/08 Purple Heart.mp3
/home/ari/Music/Sabaton/Primo Victoria (Re-Armed)/09 Metal Machine.mp3
/home/ari/Music/Sabaton/Primo Victoria (Re-Armed)/10 The March To War.mp3
/home/ari/Music/Sabaton/Primo Victoria (Re-Armed)/11 Shotgun.mp3
/home/ari/Music/Sabaton/Primo Victoria (Re-Armed)/12 Into The Fire (Live In Falun 2.mp3
/home/ari/Music/Sabaton/Primo Victoria (Re-Armed)/13 Rise Of Evil (Live In Falun 20.mp3
/home/ari/Music/Sabaton/Primo Victoria (Re-Armed)/14 The Beast (Twisted Sister Cove.mp3
/home/ari/Music/Sabaton/Primo Victoria (Re-Armed)/15 Dead Soldier's Waltz.mp3
/home/ari/Music/Saliva/In It to Win It/01 Animal.mp3
/home/ari/Music/Saliva/In It to Win It/02 She Can Sure Hide Crazy.mp3
/home/ari/Music/Saliva/In It to Win It/03 In It to Win It.mp3
/home/ari/Music/Saliva/In It to Win It/04 Choke.mp3
/home/ari/Music/Saliva/In It to Win It/05 Redneck Freakshow.mp3
/home/ari/Music/Saliva/In It to Win It/06 Lost.mp3
/home/ari/Music/Saliva/In It to Win It/07 1000 Eyes.mp3
/home/ari/Music/Saliva/In It to Win It/08 Flesh.mp3
/home/ari/Music/Saliva/In It to Win It/09 The Enemy.mp3
/home/ari/Music/Saliva/In It to Win It/10 Rise Up.mp3
/home/ari/Music/Saliva/In It to Win It/11 I Dont Want It.mp3
/home/ari/Music/Saliva/In It to Win It/12 I_D_N_A_E_.mp3
/home/ari/Music/Saliva/In It to Win It/13 No One but Me.mp3
/home/ari/Music/Saliva/In It to Win It/14 Army.mp3
/home/ari/Music/Saliva/In It to Win It/15 Closer.mp3
/home/ari/Music/Scar Symmetry/Holographic Universe/01 Morphogenesis.mp3
/home/ari/Music/Scar Symmetry/Holographic Universe/02 Timewave Zero.mp3
/home/ari/Music/Scar Symmetry/Holographic Universe/03 Quantumleaper.mp3
/home/ari/Music/Scar Symmetry/Holographic Universe/04 Artificial Sun Projection.mp3
/home/ari/Music/Scar Symmetry/Holographic Universe/05 The Missing Coordinates.mp3
/home/ari/Music/Scar Symmetry/Holographic Universe/06 Ghost Prototype I - Measuremen.mp3
/home/ari/Music/Scar Symmetry/Holographic Universe/07 Fear Catalyst.mp3
/home/ari/Music/Scar Symmetry/Holographic Universe/08 Trapezoid.mp3
/home/ari/Music/Scar Symmetry/Holographic Universe/09 Prism And Gate.mp3
/home/ari/Music/Scar Symmetry/Holographic Universe/10 Holographic Universe.mp3
/home/ari/Music/Scar Symmetry/Holographic Universe/11 The Three-Dimensional Shadow.mp3
/home/ari/Music/Scar Symmetry/Holographic Universe/12 Ghost Prototype II - Deus Ex M.mp3
/home/ari/Music/Scar Symmetry/Dark Matter Dimensions (Bonus/01 The Iconoclast.mp3
/home/ari/Music/Scar Symmetry/Dark Matter Dimensions (Bonus/02 The Consciousness Eaters.mp3
/home/ari/Music/Scar Symmetry/Dark Matter Dimensions (Bonus/03 Noumenon And Phenomenon.mp3
/home/ari/Music/Scar Symmetry/Dark Matter Dimensions (Bonus/04 Ascension Chamber.mp3
/home/ari/Music/Scar Symmetry/Dark Matter Dimensions (Bonus/05 Mechanical Soul Cybernetics.mp3
/home/ari/Music/Scar Symmetry/Dark Matter Dimensions (Bonus/06 Nonhuman Era.mp3
/home/ari/Music/Scar Symmetry/Dark Matter Dimensions (Bonus/07 Dark Matter Dimensions.mp3
/home/ari/Music/Scar Symmetry/Dark Matter Dimensions (Bonus/08 Sculpture Void.mp3
/home/ari/Music/Scar Symmetry/Dark Matter Dimensions (Bonus/09 A Paranthesis In Eternity.mp3
/home/ari/Music/Scar Symmetry/Dark Matter Dimensions (Bonus/10 Frequencyshifter.mp3
/home/ari/Music/Scar Symmetry/Dark Matter Dimensions (Bonus/11 Radiant Strain.mp3
/home/ari/Music/Scar Symmetry/Dark Matter Dimensions (Bonus/12 Pariah (Bonus Track).mp3
/home/ari/Music/Shadows Fall/Fire From The Sky/01 The Unknown.mp3
/home/ari/Music/Shadows Fall/Fire From The Sky/02 Divide And Conquer.mp3
/home/ari/Music/Shadows Fall/Fire From The Sky/03 Weight Of The World.mp3
/home/ari/Music/Shadows Fall/Fire From The Sky/04 Nothing Remains.mp3
/home/ari/Music/Shadows Fall/Fire From The Sky/05 Fire From The Sky.mp3
/home/ari/Music/Shadows Fall/Fire From The Sky/06 Save Your Soul.mp3
/home/ari/Music/Shadows Fall/Fire From The Sky/07 Blind Faith.mp3
/home/ari/Music/Shadows Fall/Fire From The Sky/08 Lost Within.mp3
/home/ari/Music/Shadows Fall/Fire From The Sky/09 Walk The Edge.mp3
/home/ari/Music/Shadows Fall/Fire From The Sky/10 The Wasteland.mp3
/home/ari/Music/Shinedown/Leave A Whisper/01 Fly From The Inside.mp3
/home/ari/Music/Shinedown/Leave A Whisper/02 Left Out.mp3
/home/ari/Music/Shinedown/Leave A Whisper/03 Lost In The Crowd.mp3
/home/ari/Music/Shinedown/Leave A Whisper/04 No More Love.mp3
/home/ari/Music/Shinedown/Leave A Whisper/05 Better Version.mp3
/home/ari/Music/Shinedown/Leave A Whisper/06 Burning Bright.mp3
/home/ari/Music/Shinedown/Leave A Whisper/07 In Memory.mp3
/home/ari/Music/Shinedown/Leave A Whisper/08 All I Ever Wanted.mp3
/home/ari/Music/Shinedown/Leave A Whisper/09 Stranger Inside.mp3
/home/ari/Music/Shinedown/Leave A Whisper/10 Lacerated.mp3
/home/ari/Music/Shinedown/Leave A Whisper/11 Crying Out.mp3
/home/ari/Music/Shinedown/Leave A Whisper/12 45.mp3
/home/ari/Music/Shinedown/The Sound of Madness (Deluxe)/01 Devour.mp3
/home/ari/Music/Shinedown/The Sound of Madness (Deluxe)/02 Sound Of Madness.mp3
/home/ari/Music/Shinedown/The Sound of Madness (Deluxe)/03 Second Chance.mp3
/home/ari/Music/Shinedown/The Sound of Madness (Deluxe)/04 Cry For Help.mp3
/home/ari/Music/Shinedown/The Sound of Madness (Deluxe)/05 The Crow & The Butterfly.mp3
/home/ari/Music/Shinedown/The Sound of Madness (Deluxe)/06 If You Only Knew.mp3
/home/ari/Music/Shinedown/The Sound of Madness (Deluxe)/07 Sin With A Grin.mp3
/home/ari/Music/Shinedown/The Sound of Madness (Deluxe)/08 What A Shame.mp3
/home/ari/Music/Shinedown/The Sound of Madness (Deluxe)/09 Cyanide Sweet Tooth Suicide.mp3
/home/ari/Music/Shinedown/The Sound of Madness (Deluxe)/10 Breaking Inside.mp3
/home/ari/Music/Shinedown/The Sound of Madness (Deluxe)/11 Call Me.mp3
/home/ari/Music/Shinedown/The Sound of Madness (Deluxe)/12 The Energy (Explicit Bonus Tra.mp3
/home/ari/Music/Shinedown/The Sound of Madness (Deluxe)/13 Son Of Sam (Bonus Track).mp3
/home/ari/Music/Shinedown/The Sound of Madness (Deluxe)/14 I Own You (Bonus Track).mp3
/home/ari/Music/Shinedown/The Sound of Madness (Deluxe)/15 Junkies For Fame (Bonus Track).mp3
/home/ari/Music/Shinedown/The Sound of Madness (Deluxe)/16 Second Chance (Acoustic) _Bonu.mp3
/home/ari/Music/Shinedown/The Sound of Madness (Deluxe)/17 The Crow & The Butterfly (Pull.mp3
/home/ari/Music/Shinedown/The Sound of Madness (Deluxe)/18 Her Name Is Alice (Bonus Track.mp3
/home/ari/Music/Shinedown/The Sound of Madness (Deluxe)/19 Diamond Eyes (Boom-Lay Boom-La.mp3
/home/ari/Music/Shinedown/The Sound of Madness (Deluxe)/20 Breaking Inside (feat_ Lzzy Ha.mp3
/home/ari/Music/Shinedown/Threat to Survival/01 Asking For It.mp3
/home/ari/Music/Shinedown/Threat to Survival/02 Cut The Cord.mp3
/home/ari/Music/Shinedown/Threat to Survival/03 State Of My Head.mp3
/home/ari/Music/Shinedown/Threat to Survival/04 Outcast.mp3
/home/ari/Music/Shinedown/Threat to Survival/05 How Did You Love.mp3
/home/ari/Music/Shinedown/Threat to Survival/06 It All Adds Up.mp3
/home/ari/Music/Shinedown/Threat to Survival/07 Oblivion.mp3
/home/ari/Music/Shinedown/Threat to Survival/08 Dangerous.mp3
/home/ari/Music/Shinedown/Threat to Survival/09 Thick As Thieves.mp3
/home/ari/Music/Shinedown/Threat to Survival/10 Black Cadillac.mp3
/home/ari/Music/Shinedown/Threat to Survival/11 Misfits.mp3
/home/ari/Music/Soilwork/Stabbing the Drama/01 Stabbing the Drama.mp3
/home/ari/Music/Soilwork/Stabbing the Drama/02 One With the Flies.mp3
/home/ari/Music/Soilwork/Stabbing the Drama/03 Weapon of Vanity.mp3
/home/ari/Music/Soilwork/Stabbing the Drama/04 The Crestfallen.mp3
/home/ari/Music/Soilwork/Stabbing the Drama/05 Nerve.mp3
/home/ari/Music/Soilwork/Stabbing the Drama/06 Stalemate.mp3
/home/ari/Music/Soilwork/Stabbing the Drama/07 Distance.mp3
/home/ari/Music/Soilwork/Stabbing the Drama/08 Observation Slave.mp3
/home/ari/Music/Soilwork/Stabbing the Drama/09 Fate in Motion.mp3
/home/ari/Music/Soilwork/Stabbing the Drama/10 Blind Eye Halo.mp3
/home/ari/Music/Soilwork/Stabbing the Drama/11 If Possible.mp3
/home/ari/Music/Thousand Foot Krutch/The End Is Where We Begin/10 War of Change.mp3
/home/ari/Music/Three Days Grace/Life Starts Now/01 Bitter Taste.mp3
/home/ari/Music/Three Days Grace/Life Starts Now/02 Break(1).mp3
/home/ari/Music/Three Days Grace/Life Starts Now/02 Break.mp3
/home/ari/Music/Three Days Grace/Life Starts Now/03 World so Cold.mp3
/home/ari/Music/Three Days Grace/Life Starts Now/04 Lost in You.mp3
/home/ari/Music/Three Days Grace/Life Starts Now/05 The Good Life(1).mp3
/home/ari/Music/Three Days Grace/Life Starts Now/05 The Good Life.mp3
/home/ari/Music/Three Days Grace/Life Starts Now/06 No More.mp3
/home/ari/Music/Three Days Grace/Life Starts Now/07 Last to Know.mp3
/home/ari/Music/Three Days Grace/Life Starts Now/08 Someone Who Cares.mp3
/home/ari/Music/Three Days Grace/Life Starts Now/09 Bully.mp3
/home/ari/Music/Three Days Grace/Life Starts Now/10 Without You.mp3
/home/ari/Music/Three Days Grace/Life Starts Now/11 Goin' Down.mp3
/home/ari/Music/Three Days Grace/Life Starts Now/12 Life Starts Now.mp3
/home/ari/Music/Three Days Grace/Human/01 Human Race.mp3
/home/ari/Music/Three Days Grace/Human/02 Painkiller.mp3
/home/ari/Music/Three Days Grace/Human/03 Fallen Angel.mp3
/home/ari/Music/Three Days Grace/Human/04 Landmine.mp3
/home/ari/Music/Three Days Grace/Human/05 Tell Me Why.mp3
/home/ari/Music/Three Days Grace/Human/06 I Am Machine.mp3
/home/ari/Music/Three Days Grace/Human/07 So What.mp3
/home/ari/Music/Three Days Grace/Human/08 Car Crash.mp3
/home/ari/Music/Three Days Grace/Human/09 Nothing's Fair In Love And War.mp3
/home/ari/Music/Three Days Grace/Human/10 One Too Many.mp3
/home/ari/Music/Three Days Grace/Human/11 The End Is Not The Answer.mp3
/home/ari/Music/Three Days Grace/Human/12 The Real You.mp3
/home/ari/Music/Trapt/The Acoustic Collection/01 Headstrong (Acoustic).mp3
/home/ari/Music/Trapt/The Acoustic Collection/02 Echo (Acoustic).mp3
/home/ari/Music/Trapt/The Acoustic Collection/03 Only One In Color (Acoustic).mp3
/home/ari/Music/Trapt/The Acoustic Collection/04 Contagious (Acoustic).mp3
/home/ari/Music/Trapt/The Acoustic Collection/05 These Walls (Acoustic).mp3
/home/ari/Music/Trapt/The Acoustic Collection/06 Ready When You Are (Acoustic).mp3
/home/ari/Music/Trapt/The Acoustic Collection/07 Black Rose (Acoustic).mp3
/home/ari/Music/Trapt/The Acoustic Collection/08 Waiting (Acoustic).mp3
/home/ari/Music/Trapt/The Acoustic Collection/09 Lost Realist (Acoustic).mp3
/home/ari/Music/Trapt/The Acoustic Collection/10 Made Of Glass (Acoustic).mp3
/home/ari/Music/Trapt/The Acoustic Collection/11 Too Close (Acoustic).mp3
/home/ari/Music/Trapt/The Acoustic Collection/12 Who's Going Home With You Toni.mp3
/home/ari/Music/Trapt/The Acoustic Collection/13 Love Hate Relationship (Acoust.mp3
/home/ari/Music/Trapt/Trapt (PA Version)/01 Headstrong.mp3
/home/ari/Music/Trivium/Silence In The Snow (Special E/01 Snøfall.mp3
/home/ari/Music/Trivium/Silence In The Snow (Special E/02 Silence In The Snow.mp3
/home/ari/Music/Trivium/Silence In The Snow (Special E/03 Blind Leading The Blind.mp3
/home/ari/Music/Trivium/Silence In The Snow (Special E/04 Dead And Gone.mp3
/home/ari/Music/Trivium/Silence In The Snow (Special E/05 The Ghost That's Haunting You.mp3
/home/ari/Music/Trivium/Silence In The Snow (Special E/06 Pull Me From The Void.mp3
/home/ari/Music/Trivium/Silence In The Snow (Special E/07 Until The World Goes Cold.mp3
/home/ari/Music/Trivium/Silence In The Snow (Special E/08 Rise Above The Tides.mp3
/home/ari/Music/Trivium/Silence In The Snow (Special E/09 The Thing That's Killing Me.mp3
/home/ari/Music/Trivium/Silence In The Snow (Special E/10 Beneath The Sun.mp3
/home/ari/Music/Trivium/Silence In The Snow (Special E/11 Breathe In The Flames.mp3
/home/ari/Music/Trivium/Silence In The Snow (Special E/12 Cease All Your Fire.mp3
/home/ari/Music/Trivium/Silence In The Snow (Special E/13 The Darkness Of My Mind.mp3
/home/ari/Music/Trivium/Ember to Inferno/01 Inception_ The Bleeding Skies.mp3
/home/ari/Music/Trivium/Ember to Inferno/02 Pillars of Serpents.mp3
/home/ari/Music/Trivium/Ember to Inferno/03 If I Could Collapse the Masses.mp3
/home/ari/Music/Trivium/Ember to Inferno/04 Fugue (A Revelation).mp3
/home/ari/Music/Trivium/Ember to Inferno/05 Requiem.mp3
/home/ari/Music/Trivium/Ember to Inferno/06 Ember to Inferno.mp3
/home/ari/Music/Trivium/Ember to Inferno/07 Ashes.mp3
/home/ari/Music/Trivium/Ember to Inferno/08 To Burn the Eye.mp3
/home/ari/Music/Trivium/Ember to Inferno/09 Falling to Grey.mp3
/home/ari/Music/Trivium/Ember to Inferno/10 My Hatred.mp3
/home/ari/Music/Trivium/Ember to Inferno/11 When All Light Dies.mp3
/home/ari/Music/Trivium/Ember to Inferno/12 A View of Burning Empires.mp3
/home/ari/Music/Trivium/Shogun (Special Edition)/01 Kirisute Gomen.mp3
/home/ari/Music/Trivium/Shogun (Special Edition)/02 Torn Between Scylla and Charyb.mp3
/home/ari/Music/Trivium/Shogun (Special Edition)/03 Down From The Sky.mp3
/home/ari/Music/Trivium/Shogun (Special Edition)/04 Into The Mouth Of Hell We Marc.mp3
/home/ari/Music/Trivium/Shogun (Special Edition)/05 Throes Of Perdition.mp3
/home/ari/Music/Trivium/Shogun (Special Edition)/06 Insurrection.mp3
/home/ari/Music/Trivium/Shogun (Special Edition)/07 The Calamity.mp3
/home/ari/Music/Trivium/Shogun (Special Edition)/08 He Who Spawned The Furies.mp3
/home/ari/Music/Trivium/Shogun (Special Edition)/09 Of Prometheus And The Crucifix.mp3
/home/ari/Music/Trivium/Shogun (Special Edition)/10 Like Callisto To A Star In Hea.mp3
/home/ari/Music/Trivium/Shogun (Special Edition)/11 Shogun _with fade_ for special.mp3
/home/ari/Music/Trivium/Shogun (Special Edition)/12 Poison_ The Knife Or The Noose.mp3
/home/ari/Music/Trivium/Shogun (Special Edition)/13 Upon The Shores.mp3
/home/ari/Music/Trivium/Shogun (Special Edition)/14 Iron Maiden.mp3
/home/ari/Music/Trivium/Ascendancy _Special Edition_/01 The End Of Everything.mp3
/home/ari/Music/Trivium/Ascendancy _Special Edition_/02 Rain.mp3
/home/ari/Music/Trivium/Ascendancy _Special Edition_/03 Pull Harder On The Strings Of.mp3
/home/ari/Music/Trivium/Ascendancy _Special Edition_/04 Drowned And Torn Asunder.mp3
/home/ari/Music/Trivium/Ascendancy _Special Edition_/05 Ascendancy.mp3
/home/ari/Music/Trivium/Ascendancy _Special Edition_/06 A Gunshot To The Head Of Trepi.mp3
/home/ari/Music/Trivium/Ascendancy _Special Edition_/07 Like Light To The Flies.mp3
/home/ari/Music/Trivium/Ascendancy _Special Edition_/08 Dying In Your Arms.mp3
/home/ari/Music/Trivium/Ascendancy _Special Edition_/09 The Deceived.mp3
/home/ari/Music/Trivium/Ascendancy _Special Edition_/10 Suffocating Sight.mp3
/home/ari/Music/Trivium/Ascendancy _Special Edition_/11 Departure.mp3
/home/ari/Music/Trivium/Ascendancy _Special Edition_/12 Declaration.mp3
/home/ari/Music/Trivium/Ascendancy _Special Edition_/13 Blinding Tears Will Break The.mp3
/home/ari/Music/Trivium/Ascendancy _Special Edition_/14 Washing Away Me In The Tides.mp3
/home/ari/Music/Trivium/Ascendancy _Special Edition_/15 Master Of Puppets.mp3
/home/ari/Music/Trivium/Ascendancy _Special Edition_/16 Dying In Your Arms (Radio Mix).mp3
/home/ari/Music/Trivium/The Crusade _Special Edition_/01 Ignition.mp3
/home/ari/Music/Trivium/The Crusade _Special Edition_/02 Detonation.mp3
/home/ari/Music/Trivium/The Crusade _Special Edition_/03 Entrance Of The Conflagration.mp3
/home/ari/Music/Trivium/The Crusade _Special Edition_/04 Anthem (We Are The Fire).mp3
/home/ari/Music/Trivium/The Crusade _Special Edition_/05 Unrepentant.mp3
/home/ari/Music/Trivium/The Crusade _Special Edition_/06 And Sadness Will Sear.mp3
/home/ari/Music/Trivium/The Crusade _Special Edition_/07 Becoming The Dragon.mp3
/home/ari/Music/Trivium/The Crusade _Special Edition_/08 To The Rats.mp3
/home/ari/Music/Trivium/The Crusade _Special Edition_/09 This World Can't Tear Us Apart.mp3
/home/ari/Music/Trivium/The Crusade _Special Edition_/10 Tread The Floods.mp3
/home/ari/Music/Trivium/The Crusade _Special Edition_/11 Contempt Breeds Contamination.mp3
/home/ari/Music/Trivium/The Crusade _Special Edition_/12 The Rising.mp3
/home/ari/Music/Trivium/The Crusade _Special Edition_/13 The Crusade.mp3
/home/ari/Music/Trivium/The Crusade _Special Edition_/14 Broken One.mp3
/home/ari/Music/Trivium/The Crusade _Special Edition_/15 Vengeance.mp3
/home/ari/Music/Trivium/In Waves (Special Edition)/01 Capsizing The Sea.mp3
/home/ari/Music/Trivium/In Waves (Special Edition)/02 In Waves.mp3
/home/ari/Music/Trivium/In Waves (Special Edition)/03 Inception Of The End.mp3
/home/ari/Music/Trivium/In Waves (Special Edition)/04 Dusk Dismantled.mp3
/home/ari/Music/Trivium/In Waves (Special Edition)/05 Watch The World Burn.mp3
/home/ari/Music/Trivium/In Waves (Special Edition)/06 Black.mp3
/home/ari/Music/Trivium/In Waves (Special Edition)/07 A Skyline's Severance.mp3
/home/ari/Music/Trivium/In Waves (Special Edition)/08 Ensnare The Sun.mp3
/home/ari/Music/Trivium/In Waves (Special Edition)/09 Built To Fall.mp3
/home/ari/Music/Trivium/In Waves (Special Edition)/10 Caustic Are The Ties That Bind.mp3
/home/ari/Music/Trivium/In Waves (Special Edition)/11 Forsake Not The Dream.mp3
/home/ari/Music/Trivium/In Waves (Special Edition)/12 Drowning In Slow Motion.mp3
/home/ari/Music/Trivium/In Waves (Special Edition)/13 A Grey So Dark.mp3
/home/ari/Music/Trivium/In Waves (Special Edition)/14 Chaos Reigns.mp3
/home/ari/Music/Trivium/In Waves (Special Edition)/15 Of All These Yesterdays.mp3
/home/ari/Music/Trivium/In Waves (Special Edition)/16 Leaving This World Behind.mp3
/home/ari/Music/Trivium/In Waves (Special Edition)/17 Shattering The Skies Above.mp3
/home/ari/Music/Trivium/In Waves (Special Edition)/18 Slave New World.mp3
/home/ari/Music/Trivium/Vengeance Falls/01 Brave This Storm.mp3
/home/ari/Music/Trivium/Vengeance Falls/02 Vengeance Falls.mp3
/home/ari/Music/Trivium/Vengeance Falls/03 Strife.mp3
/home/ari/Music/Trivium/Vengeance Falls/04 No Way To Heal.mp3
/home/ari/Music/Trivium/Vengeance Falls/05 To Believe.mp3
/home/ari/Music/Trivium/Vengeance Falls/06 At The End Of This War.mp3
/home/ari/Music/Trivium/Vengeance Falls/07 Through Blood And Dirt And Bon.mp3
/home/ari/Music/Trivium/Vengeance Falls/08 Villainy Thrives.mp3
/home/ari/Music/Trivium/Vengeance Falls/09 Incineration_ The Broken World.mp3
/home/ari/Music/Trivium/Vengeance Falls/10 Wake (The End Is Nigh).mp3
/home/ari/Music/Twilight Force/Tales Of Ancient Prophecies/01 Enchanted Dragon Of Wisdom.mp3
/home/ari/Music/Twilight Force/Tales Of Ancient Prophecies/02 The Power Of The Ancient Force.mp3
/home/ari/Music/Twilight Force/Tales Of Ancient Prophecies/03 Twilight Horizon.mp3
/home/ari/Music/Twilight Force/Tales Of Ancient Prophecies/04 The Summoning.mp3
/home/ari/Music/Twilight Force/Tales Of Ancient Prophecies/05 Whispering Winds.mp3
/home/ari/Music/Twilight Force/Tales Of Ancient Prophecies/06 Fall Of The Eternal Winter.mp3
/home/ari/Music/Twilight Force/Tales Of Ancient Prophecies/07 Forest Of Destiny.mp3
/home/ari/Music/Twilight Force/Tales Of Ancient Prophecies/08 In The Mighty Hall Of The Fire.mp3
/home/ari/Music/Twilight Force/Tales Of Ancient Prophecies/09 Made Of Steel.mp3
/home/ari/Music/Twilight Force/Tales Of Ancient Prophecies/10 Sword Of Magic Steel.mp3
/home/ari/Music/Twilight Force/Tales Of Ancient Prophecies/11 Gates Of Glory.mp3
/home/ari/Music/Twilight Force/Heroes of Mighty Magic/01 Battle of Arcane Might.mp3
/home/ari/Music/Twilight Force/Heroes of Mighty Magic/02 Powerwind.mp3
/home/ari/Music/Twilight Force/Heroes of Mighty Magic/03 Guardian of the Seas.mp3
/home/ari/Music/Twilight Force/Heroes of Mighty Magic/04 Flight of the Sapphire Dragon.mp3
/home/ari/Music/Twilight Force/Heroes of Mighty Magic/05 There and Back Again.mp3
/home/ari/Music/Twilight Force/Heroes of Mighty Magic/06 Riders of the Dawn.mp3
/home/ari/Music/Twilight Force/Heroes of Mighty Magic/07 Keepers of Fate.mp3
/home/ari/Music/Twilight Force/Heroes of Mighty Magic/08 Rise of a Hero.mp3
/home/ari/Music/Twilight Force/Heroes of Mighty Magic/09 To the Stars.mp3
/home/ari/Music/Twilight Force/Heroes of Mighty Magic/10 Heroes of Mighty Magic.mp3
/home/ari/Music/Twilight Force/Heroes of Mighty Magic/11 Epilogue.mp3
/home/ari/Music/Twilight Force/Heroes of Mighty Magic/12 Knights of Twilight's Might.mp3
/home/ari/Music/Unleash The Archers/Time Stands Still/01 Northern Passage.mp3
/home/ari/Music/Unleash The Archers/Time Stands Still/02 Frozen Steel.mp3
/home/ari/Music/Unleash The Archers/Time Stands Still/03 Hall Of The Tide.mp3
/home/ari/Music/Unleash The Archers/Time Stands Still/04 Tonight We Ride.mp3
/home/ari/Music/Unleash The Archers/Time Stands Still/05 Test Your Metal.mp3
/home/ari/Music/Unleash The Archers/Time Stands Still/06 Crypt.mp3
/home/ari/Music/Unleash The Archers/Time Stands Still/07 No More Heroes.mp3
/home/ari/Music/Unleash The Archers/Time Stands Still/08 Dreamcrusher.mp3
/home/ari/Music/Unleash The Archers/Time Stands Still/09 Going Down Fighting.mp3
/home/ari/Music/Unleash The Archers/Time Stands Still/10 Time Stands Still.mp3
/home/ari/Music/Unleash The Archers/Time Stands Still/11 Tonight We Ride (Video Edit).mp3
